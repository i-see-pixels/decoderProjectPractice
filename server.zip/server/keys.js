module.exports={
    JWT_SECRET_KEY:"vikas0901",
    ADMIN_PRIVILEDGE:"ridhu"
}